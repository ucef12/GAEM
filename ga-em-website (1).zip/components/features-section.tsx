"use client"

import { Battery, Cpu, Database, Truck, BotIcon as Robot, Cog } from "lucide-react"
import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import Image from "next/image"

const features = [
  {
    icon: Cpu,
    title: "Automation Excellence",
    description: "Cutting-edge automation solutions for Industry 4.0 and IoT integration.",
    color: "text-red-600",
    bgColor: "bg-red-100",
    borderColor: "border-red-500",
  },
  {
    icon: Battery,
    title: "e-Mobility Solutions",
    description: "Advanced electric mobility solutions including forklifts, AGVs, and robots.",
    color: "text-yellow-600",
    bgColor: "bg-yellow-100",
    borderColor: "border-yellow-500",
  },
  {
    icon: Database,
    title: "Data Center Monitoring",
    description: "Comprehensive monitoring solutions for modern data centers.",
    color: "text-gray-800",
    bgColor: "bg-gray-100",
    borderColor: "border-gray-800",
  },
]

const industrialComponents = [
  {
    title: "Gateway/EDGE Computing",
    description: "Edge computing solutions for real-time data processing and analysis.",
    icon: Cpu,
  },
  {
    title: "PLC Integration",
    description: "Seamless integration with programmable logic controllers for industrial automation.",
    icon: Cog,
  },
  {
    title: "Machine Tools with CNC",
    description: "Advanced CNC machine tools for precision manufacturing.",
    icon: Cog,
  },
  {
    title: "Industrial Communication",
    description: "Wired and wireless communication solutions for industrial environments.",
    icon: Database,
  },
  {
    title: "Machine Vision",
    description: "Computer vision systems for quality control and process monitoring.",
    icon: Cpu,
  },
  {
    title: "AGV Solutions",
    description: "Automated Guided Vehicles for efficient material handling.",
    icon: Truck,
  },
  {
    title: "Environmental Control",
    description: "Systems for monitoring and controlling environmental conditions.",
    icon: Database,
  },
  {
    title: "Robot Control",
    description: "Advanced robotics control systems for industrial automation.",
    icon: Robot,
  },
]

export default function FeaturesSection() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const containerVariants = {
    hidden: {},
    show: {
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  }

  return (
    <section ref={ref} className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: -20 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Solutions</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Supporting companies in their digital transformation and process optimization journey
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "show" : "hidden"}
          className="grid md:grid-cols-3 gap-8 mb-20"
        >
          {features.map((feature, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              className={`bg-white p-8 rounded-lg shadow-md hover:shadow-lg transition-shadow border-t-4 ${feature.borderColor}`}
            >
              <div className={`w-16 h-16 ${feature.bgColor} rounded-full flex items-center justify-center mb-6`}>
                <feature.icon className={`w-8 h-8 ${feature.color}`} />
              </div>
              <h3 className="text-xl font-bold mb-4">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </motion.div>
          ))}
        </motion.div>

        <motion.div
          variants={itemVariants}
          initial="hidden"
          animate={inView ? "show" : "hidden"}
          className="bg-white p-8 rounded-xl shadow-lg mb-16"
        >
          <h3 className="text-2xl font-bold mb-6 text-center">Industrial Automation Ecosystem</h3>

          <div className="flex justify-center mb-10">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/home%20page.PNG-ebgtP08SdiRNh3aFYsBdqi1cKNGXDd.png"
              alt="Industrial Automation Diagram"
              width={600}
              height={400}
              className="rounded-lg shadow-md"
            />
          </div>

          <div className="grid md:grid-cols-4 gap-6">
            {industrialComponents.map((component, index) => (
              <div
                key={index}
                className="bg-gray-50 p-4 rounded-lg border border-gray-200 hover:border-red-500 transition-colors"
              >
                <component.icon className="w-8 h-8 text-red-600 mb-3" />
                <h4 className="font-bold mb-2">{component.title}</h4>
                <p className="text-sm text-gray-600">{component.description}</p>
              </div>
            ))}
          </div>
        </motion.div>

        <motion.div
          variants={itemVariants}
          initial="hidden"
          animate={inView ? "show" : "hidden"}
          className="text-center"
        >
          <h3 className="text-2xl font-bold mb-4">Digital Transformation Journey</h3>
          <p className="text-gray-600 max-w-3xl mx-auto mb-8">
            We help companies navigate their digital transformation journey with our comprehensive suite of automation
            and e-mobility solutions.
          </p>
          <div className="flex justify-center">
            <div className="bg-white p-6 rounded-xl shadow-lg inline-flex">
              <div className="flex flex-col md:flex-row items-center gap-4">
                <div className="flex flex-col items-center p-4 bg-red-50 rounded-lg">
                  <Cpu className="w-10 h-10 text-red-600 mb-2" />
                  <span className="font-bold">Assessment</span>
                </div>
                <div className="text-red-600">→</div>
                <div className="flex flex-col items-center p-4 bg-yellow-50 rounded-lg">
                  <Cog className="w-10 h-10 text-yellow-600 mb-2" />
                  <span className="font-bold">Implementation</span>
                </div>
                <div className="text-yellow-600">→</div>
                <div className="flex flex-col items-center p-4 bg-gray-100 rounded-lg">
                  <Database className="w-10 h-10 text-gray-800 mb-2" />
                  <span className="font-bold">Integration</span>
                </div>
                <div className="text-gray-800">→</div>
                <div className="flex flex-col items-center p-4 bg-green-50 rounded-lg">
                  <Battery className="w-10 h-10 text-green-600 mb-2" />
                  <span className="font-bold">Optimization</span>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

