"use client"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"
import dynamic from "next/dynamic"
import Logo from "./logo"
import Image from "next/image"

const Scene3D = dynamic(() => import("@/components/scene-3d"), { ssr: false })

export default function HeroSection() {
  return (
    <section className="relative h-screen flex items-center overflow-hidden">
      {/* 3D Background */}
      <div className="absolute inset-0 z-0">
        <Scene3D />
      </div>

      {/* Gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-transparent z-[1]"></div>

      {/* Content */}
      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-3xl"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            className="mb-8"
          >
            <div className="flex items-center gap-4">
              <Logo variant="light" size="lg" />
              <span className="text-white text-xl">German Automation & e-Mobility</span>
            </div>
          </motion.div>

          <h1 className="text-4xl md:text-6xl text-white font-bold mb-6 leading-tight">
            German Automation & e-Mobility
          </h1>
          <p className="text-xl text-white/90 mb-8 max-w-2xl">
            Leading provider of automation & e-mobility solutions supporting companies in their digital transformation
            and process optimization journey
          </p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.5 }}
            className="flex flex-wrap gap-4"
          >
            <Button size="lg" className="bg-red-600 hover:bg-red-700 text-white px-8 py-6 rounded-md transition-colors">
              Explore Solutions
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent border-white text-white hover:bg-white/10 px-8 py-6 rounded-md transition-colors"
            >
              <span>Learn More</span>
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </motion.div>
        </motion.div>
      </div>

      {/* Industry Diagram */}
      <motion.div
        className="absolute bottom-20 right-10 z-10 max-w-xl hidden lg:block"
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8, duration: 0.8 }}
      >
        <Image
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/home%20page.PNG-ebgtP08SdiRNh3aFYsBdqi1cKNGXDd.png"
          alt="Industrial Automation Diagram"
          width={600}
          height={400}
          className="rounded-lg shadow-2xl"
        />
      </motion.div>

      {/* Animated scroll indicator */}
      <motion.div
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10"
        animate={{ y: [0, 10, 0] }}
        transition={{ repeat: Number.POSITIVE_INFINITY, duration: 1.5 }}
      >
        <div className="w-8 h-12 rounded-full border-2 border-white flex items-start justify-center p-2">
          <motion.div
            className="w-1 h-3 bg-white rounded-full"
            animate={{ y: [0, 6, 0] }}
            transition={{ repeat: Number.POSITIVE_INFINITY, duration: 1.5 }}
          />
        </div>
      </motion.div>
    </section>
  )
}

