"use client"

import { Canvas } from "@react-three/fiber"
import { OrbitControls, PerspectiveCamera, Environment, Html, ContactShadows, Float } from "@react-three/drei"
import { Suspense, useState } from "react"
import { Button } from "@/components/ui/button"
import { motion } from "framer-motion"

function ForkliftPlaceholder() {
  const [hovered, setHovered] = useState(false)

  return (
    <>
      <Float speed={2} rotationIntensity={0.4} floatIntensity={0.6} position={[0, 0.5, 0]}>
        <mesh
          onPointerOver={() => setHovered(true)}
          onPointerOut={() => setHovered(false)}
          scale={hovered ? 1.05 : 1}
          position={[0, 0, 0]}
        >
          <boxGeometry args={[2, 0.8, 3]} />
          <meshStandardMaterial color="#ff3e00" metalness={0.8} roughness={0.2} />

          {/* Forklift forks */}
          <mesh position={[0, -0.4, 1.8]}>
            <boxGeometry args={[1.8, 0.1, 0.8]} />
            <meshStandardMaterial color="#aaa" metalness={0.9} roughness={0.2} />
          </mesh>

          {/* Forklift cabin */}
          <mesh position={[0, 0.6, -0.8]}>
            <boxGeometry args={[1.6, 1, 1.2]} />
            <meshStandardMaterial color="#222" metalness={0.5} roughness={0.5} />
          </mesh>

          {/* Wheels */}
          <mesh position={[-0.8, -0.5, -1]}>
            <cylinderGeometry args={[0.4, 0.4, 0.3, 16]} rotation={[Math.PI / 2, 0, 0]} />
            <meshStandardMaterial color="#111" metalness={0.5} roughness={0.5} />
          </mesh>
          <mesh position={[0.8, -0.5, -1]}>
            <cylinderGeometry args={[0.4, 0.4, 0.3, 16]} rotation={[Math.PI / 2, 0, 0]} />
            <meshStandardMaterial color="#111" metalness={0.5} roughness={0.5} />
          </mesh>
          <mesh position={[-0.8, -0.5, 1]}>
            <cylinderGeometry args={[0.4, 0.4, 0.3, 16]} rotation={[Math.PI / 2, 0, 0]} />
            <meshStandardMaterial color="#111" metalness={0.5} roughness={0.5} />
          </mesh>
          <mesh position={[0.8, -0.5, 1]}>
            <cylinderGeometry args={[0.4, 0.4, 0.3, 16]} rotation={[Math.PI / 2, 0, 0]} />
            <meshStandardMaterial color="#111" metalness={0.5} roughness={0.5} />
          </mesh>
        </mesh>
      </Float>

      <Html position={[0, 2.5, 0]} center>
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.8 }}
          className="bg-white p-6 rounded-xl shadow-xl text-center w-[280px]"
        >
          <h3 className="font-bold text-xl mb-2 text-yellow-600">Electric Forklift</h3>
          <p className="text-sm mb-4 text-gray-600">Advanced battery technology with fast charging capabilities</p>
          <div className="flex justify-between text-sm text-gray-500 mb-4">
            <span>Range: 8h</span>
            <span>|</span>
            <span>Capacity: 2.5t</span>
            <span>|</span>
            <span>Lift: 3.5m</span>
          </div>
          <Button size="sm" className="bg-yellow-600 hover:bg-yellow-700 text-white w-full">
            View Specifications
          </Button>
        </motion.div>
      </Html>
    </>
  )
}

export default function ForkliftModel() {
  return (
    <Canvas>
      <color attach="background" args={["#f8f9fa"]} />
      <PerspectiveCamera makeDefault position={[6, 5, 6]} fov={35} />
      <ambientLight intensity={0.5} />
      <directionalLight position={[10, 10, 5]} intensity={1} castShadow />
      <directionalLight position={[-10, -10, -5]} intensity={0.5} />

      <Suspense fallback={null}>
        <ForkliftPlaceholder />
        <ContactShadows position={[0, -1.5, 0]} opacity={0.4} scale={10} blur={2.5} />
        <Environment preset="warehouse" />
      </Suspense>

      <OrbitControls enableZoom={true} enablePan={true} minPolarAngle={Math.PI / 6} maxPolarAngle={Math.PI / 2} />
    </Canvas>
  )
}

