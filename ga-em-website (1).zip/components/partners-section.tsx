"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import Image from "next/image"

export default function PartnersSection() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const partners = [
    { name: "BYD", logo: "/placeholder.svg?height=80&width=120" },
    { name: "HELI", logo: "/placeholder.svg?height=80&width=120" },
  ]

  return (
    <section ref={ref} className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.6 }}
          className="text-3xl font-bold text-center mb-12"
        >
          Our Partners
        </motion.h2>
        <motion.div
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : { opacity: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="flex flex-wrap justify-center items-center gap-12"
        >
          {partners.map((partner, index) => (
            <motion.div key={index} whileHover={{ scale: 1.05 }} className="flex flex-col items-center">
              <div className="bg-gray-50 p-4 rounded-lg shadow-sm mb-2">
                <Image src={partner.logo || "/placeholder.svg"} alt={`${partner.name} logo`} width={120} height={80} />
              </div>
              <span className="text-lg font-bold">{partner.name}</span>
            </motion.div>
          ))}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="mt-16 text-center"
        >
          <p className="text-gray-600 max-w-2xl mx-auto">
            We collaborate with industry leaders to deliver cutting-edge automation and e-mobility solutions that drive
            innovation and efficiency.
          </p>
        </motion.div>
      </div>
    </section>
  )
}

