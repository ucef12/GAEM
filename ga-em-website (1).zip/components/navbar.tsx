"use client"

import { useState, useEffect } from "react"
import { ChevronDown, Menu, X } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { cn } from "@/lib/utils"
import Logo from "./logo"

interface NavbarProps {
  setCurrentPage: (page: string) => void
  setCurrentSubPage: (subpage: string | null) => void
  currentPage: string
}

export default function Navbar({ setCurrentPage, setCurrentSubPage, currentPage }: NavbarProps) {
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  const navItems = {
    "About Us": [],
    Automation: ["Data Center Monitoring", "Industry 4.0", "IoT Gateway"],
    "e-Mobility": ["e-Forklifts", "AGVs", "Robots"],
    Services: [],
    "Contact Us": [],
  }

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const toggleDropdown = (item: string) => {
    setActiveDropdown(activeDropdown === item ? null : item)
  }

  return (
    <header
      className={cn(
        "fixed w-full top-0 z-50 transition-all duration-300",
        scrolled ? "bg-white/95 backdrop-blur-sm shadow-md py-2" : "bg-transparent py-4",
      )}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div
            className="cursor-pointer"
            onClick={() => {
              setCurrentPage("home")
              setCurrentSubPage(null)
            }}
          >
            <Logo variant={scrolled ? "dark" : "light"} />
          </div>

          {/* Desktop Navigation - Horizontal at the same level as logo */}
          <nav className="hidden md:flex items-center">
            <ul className="flex space-x-8">
              {Object.entries(navItems).map(([item, subitems]) => (
                <li key={item} className="relative group">
                  <button
                    className={cn(
                      "flex items-center space-x-1 py-2 hover:text-yellow-500 transition-colors",
                      currentPage === item.toLowerCase().replace(" ", "-")
                        ? "text-yellow-500"
                        : scrolled
                          ? "text-gray-800"
                          : "text-white",
                    )}
                    onClick={() => {
                      switch (item) {
                        case "About Us":
                          setCurrentPage("about")
                          break
                        case "Services":
                          setCurrentPage("services")
                          break
                        case "Contact Us":
                          setCurrentPage("contact")
                          break
                        default:
                          setCurrentPage(item.toLowerCase())
                      }
                      if (subitems.length === 0) {
                        setCurrentSubPage(null)
                      }
                      toggleDropdown(item)
                    }}
                  >
                    <span>{item}</span>
                    {subitems.length > 0 && <ChevronDown className="w-4 h-4" />}
                  </button>
                  <AnimatePresence>
                    {subitems.length > 0 && activeDropdown === item && (
                      <motion.div
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        transition={{ duration: 0.2 }}
                        className="absolute top-full left-0 bg-white shadow-lg rounded-md py-2 w-48 z-50"
                      >
                        {subitems.map((subitem) => (
                          <a
                            key={subitem}
                            href="#"
                            className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-yellow-500 transition-colors"
                            onClick={(e) => {
                              e.preventDefault()
                              setCurrentSubPage(subitem)
                              setActiveDropdown(null)
                            }}
                          >
                            {subitem}
                          </a>
                        ))}
                        {item === "e-Mobility" && (
                          <div className="px-4 py-2 text-xs text-gray-500 border-t">Partners: BYD & Heli</div>
                        )}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </li>
              ))}
            </ul>
          </nav>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              className={cn("p-2 rounded-full", scrolled ? "text-gray-800" : "text-white")}
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              <span className="sr-only">Toggle menu</span>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white shadow-lg"
          >
            <div className="container mx-auto px-4 py-4">
              <nav className="flex flex-col gap-4">
                {Object.entries(navItems).map(([item, subitems]) => (
                  <div key={item} className="border-b pb-2">
                    <button
                      className="flex items-center justify-between w-full px-2 py-2 text-gray-700"
                      onClick={() => {
                        if (subitems.length === 0) {
                          switch (item) {
                            case "About Us":
                              setCurrentPage("about")
                              break
                            case "Services":
                              setCurrentPage("services")
                              break
                            case "Contact Us":
                              setCurrentPage("contact")
                              break
                            default:
                              setCurrentPage(item.toLowerCase())
                          }
                          setCurrentSubPage(null)
                          setMobileMenuOpen(false)
                        } else {
                          toggleDropdown(item)
                        }
                      }}
                    >
                      <span>{item}</span>
                      {subitems.length > 0 && <ChevronDown className="w-4 h-4" />}
                    </button>
                    <AnimatePresence>
                      {subitems.length > 0 && activeDropdown === item && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: "auto", opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          className="overflow-hidden"
                        >
                          <div className="bg-gray-50 px-4 py-2 mt-2 rounded-md">
                            {subitems.map((subitem) => (
                              <a
                                key={subitem}
                                href="#"
                                className="block py-2 text-sm text-gray-600 hover:text-yellow-500"
                                onClick={(e) => {
                                  e.preventDefault()
                                  switch (item.toLowerCase()) {
                                    case "automation":
                                      setCurrentPage("automation")
                                      break
                                    case "e-mobility":
                                      setCurrentPage("e-mobility")
                                      break
                                  }
                                  setCurrentSubPage(subitem)
                                  setMobileMenuOpen(false)
                                  setActiveDropdown(null)
                                }}
                              >
                                {subitem}
                              </a>
                            ))}
                            {item === "e-Mobility" && (
                              <div className="text-xs text-gray-500 pt-2 border-t mt-2">Partners: BYD & Heli</div>
                            )}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                ))}
              </nav>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  )
}

