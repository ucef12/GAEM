"use client"

import { useRef, useState, useEffect } from "react"
import { Canvas, useFrame, useThree } from "@react-three/fiber"
import { Environment, Float, Text, PerspectiveCamera, OrbitControls, ContactShadows } from "@react-three/drei"
import * as THREE from "three"

function ElectricForklift({ position = [0, -1, 0], scale = 1.5 }) {
  // This is a simplified forklift model created with primitives
  const forkliftRef = useRef()

  useFrame((state) => {
    const t = state.clock.getElapsedTime()
    if (forkliftRef.current) {
      forkliftRef.current.position.y = Math.sin(t * 0.5) * 0.1 - 1
    }
  })

  return (
    <group ref={forkliftRef} position={position} scale={scale}>
      {/* Main body */}
      <mesh castShadow receiveShadow position={[0, 0.5, 0]}>
        <boxGeometry args={[2, 0.8, 3]} />
        <meshStandardMaterial color="#ff3e00" metalness={0.8} roughness={0.2} />
      </mesh>

      {/* Cabin */}
      <mesh castShadow receiveShadow position={[0, 1.2, -0.8]}>
        <boxGeometry args={[1.6, 1, 1.2]} />
        <meshStandardMaterial color="#222" metalness={0.5} roughness={0.5} />
      </mesh>

      {/* Forks */}
      <mesh castShadow receiveShadow position={[0, 0.1, 1.8]}>
        <boxGeometry args={[1.8, 0.1, 0.8]} />
        <meshStandardMaterial color="#aaa" metalness={0.9} roughness={0.2} />
      </mesh>

      {/* Wheels */}
      <mesh castShadow receiveShadow position={[-0.8, -0.2, -1]}>
        <cylinderGeometry args={[0.4, 0.4, 0.3, 16]} rotation={[Math.PI / 2, 0, 0]} />
        <meshStandardMaterial color="#111" metalness={0.5} roughness={0.5} />
      </mesh>
      <mesh castShadow receiveShadow position={[0.8, -0.2, -1]}>
        <cylinderGeometry args={[0.4, 0.4, 0.3, 16]} rotation={[Math.PI / 2, 0, 0]} />
        <meshStandardMaterial color="#111" metalness={0.5} roughness={0.5} />
      </mesh>
      <mesh castShadow receiveShadow position={[-0.8, -0.2, 1]}>
        <cylinderGeometry args={[0.4, 0.4, 0.3, 16]} rotation={[Math.PI / 2, 0, 0]} />
        <meshStandardMaterial color="#111" metalness={0.5} roughness={0.5} />
      </mesh>
      <mesh castShadow receiveShadow position={[0.8, -0.2, 1]}>
        <cylinderGeometry args={[0.4, 0.4, 0.3, 16]} rotation={[Math.PI / 2, 0, 0]} />
        <meshStandardMaterial color="#111" metalness={0.5} roughness={0.5} />
      </mesh>

      {/* Battery indicator */}
      <mesh castShadow receiveShadow position={[0, 0.9, 0.5]}>
        <boxGeometry args={[0.6, 0.2, 0.3]} />
        <meshStandardMaterial color="#00ff00" emissive="#00ff00" emissiveIntensity={0.5} />
      </mesh>

      {/* Lift mechanism */}
      <mesh castShadow receiveShadow position={[0, 0.7, 1.2]}>
        <boxGeometry args={[0.2, 1, 0.2]} />
        <meshStandardMaterial color="#555" metalness={0.8} roughness={0.2} />
      </mesh>
    </group>
  )
}

function AutomationNode({ position, text, color = "#ff3e00" }) {
  return (
    <Float speed={2} rotationIntensity={0.5} floatIntensity={1}>
      <group position={position}>
        <mesh castShadow>
          <sphereGeometry args={[0.3, 16, 16]} />
          <meshStandardMaterial color={color} metalness={0.5} roughness={0.2} />
        </mesh>
        <Text
          position={[0, 0.5, 0]}
          fontSize={0.2}
          color="white"
          font="/fonts/Geist-Bold.ttf"
          anchorX="center"
          anchorY="middle"
        >
          {text}
        </Text>
      </group>
    </Float>
  )
}

function ConnectingLines() {
  const points = [
    [-3, 1, -2],
    [0, 0, 0],
    [3, 1, -2],
    [0, 2, -3],
    [-2, -1, -1],
    [2, -1, -1],
  ]

  const lineGeometry = useRef()

  useEffect(() => {
    if (lineGeometry.current) {
      const positions = lineGeometry.current.attributes.position.array

      // Connect all points to the center (0,0,0)
      for (let i = 0; i < points.length; i++) {
        const point = points[i]

        // Start point (center)
        positions[i * 6] = 0
        positions[i * 6 + 1] = 0
        positions[i * 6 + 2] = 0

        // End point
        positions[i * 6 + 3] = point[0]
        positions[i * 6 + 4] = point[1]
        positions[i * 6 + 5] = point[2]
      }

      lineGeometry.current.attributes.position.needsUpdate = true
    }
  }, [])

  return (
    <lineSegments>
      <bufferGeometry ref={lineGeometry}>
        <bufferAttribute
          attach="attributes-position"
          count={points.length * 2}
          array={new Float32Array(points.length * 6)}
          itemSize={3}
        />
      </bufferGeometry>
      <lineBasicMaterial color="#ff3e00" opacity={0.5} transparent linewidth={1} />
    </lineSegments>
  )
}

function MovingParticles({ count = 100 }) {
  const mesh = useRef<THREE.InstancedMesh>(null!)
  const [dummy] = useState(() => new THREE.Object3D())

  useFrame(({ clock }) => {
    if (!mesh.current) return

    for (let i = 0; i < count; i++) {
      const t = clock.getElapsedTime() + i * 100

      const x = Math.sin(t * 0.1) * 10
      const y = Math.cos(t * 0.2) * 5
      const z = Math.sin(t * 0.1 + i) * 10 - 10

      dummy.position.set(x, y, z)
      dummy.updateMatrix()
      mesh.current.setMatrixAt(i, dummy.matrix)
    }

    mesh.current.instanceMatrix.needsUpdate = true
  })

  return (
    <instancedMesh ref={mesh} args={[undefined, undefined, count]}>
      <sphereGeometry args={[0.05, 16, 16]} />
      <meshBasicMaterial color="#ffffff" transparent opacity={0.6} />
    </instancedMesh>
  )
}

function Background() {
  const { scene } = useThree()

  useEffect(() => {
    scene.background = new THREE.Color("#050816")
    scene.fog = new THREE.Fog("#050816", 5, 20)
  }, [scene])

  return null
}

export default function Scene3D() {
  return (
    <Canvas shadows>
      <PerspectiveCamera makeDefault position={[5, 3, 8]} fov={45} />
      <Background />

      <ambientLight intensity={0.5} />
      <directionalLight position={[5, 5, 5]} intensity={1} castShadow />
      <spotLight position={[0, 5, 0]} intensity={0.8} castShadow />

      <MovingParticles count={150} />

      {/* Main forklift model */}
      <ElectricForklift />

      {/* Automation nodes */}
      <AutomationNode position={[-3, 1, -2]} text="Gateway/EDGE" color="#ff3e00" />
      <AutomationNode position={[3, 1, -2]} text="Machine Vision" color="#ffbb00" />
      <AutomationNode position={[0, 2, -3]} text="PLC" color="#0088ff" />
      <AutomationNode position={[-2, -1, -1]} text="Environmental" color="#00cc88" />
      <AutomationNode position={[2, -1, -1]} text="Robot Control" color="#ff3e00" />

      {/* Connecting lines between nodes */}
      <ConnectingLines />

      {/* Ground plane with shadow */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -1.5, 0]} receiveShadow>
        <planeGeometry args={[30, 30]} />
        <shadowMaterial opacity={0.2} />
      </mesh>

      <ContactShadows position={[0, -1.49, 0]} opacity={0.7} scale={10} blur={2.5} />
      <Environment preset="warehouse" />

      <OrbitControls
        enableZoom={false}
        enablePan={false}
        minPolarAngle={Math.PI / 4}
        maxPolarAngle={Math.PI / 2.2}
        autoRotate
        autoRotateSpeed={0.5}
      />
    </Canvas>
  )
}

