"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { CheckCircle, Target, Award, Users, Globe, Leaf } from "lucide-react"
import Image from "next/image"

export default function AboutUs() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const containerVariants = {
    hidden: {},
    show: {
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  }

  return (
    <section className="pt-32 pb-20 relative">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <Image
          src="https://images.unsplash.com/photo-1581091226033-d5c48150dbaa?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3"
          alt="Technology Background"
          layout="fill"
          objectFit="cover"
          className="opacity-10"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-gray-50/80 to-white/90"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block bg-red-600 text-white px-4 py-1 rounded-full text-sm font-medium mb-4">
            Our Story
          </span>
          <h1 className="text-4xl md:text-5xl font-bold mb-6">About Us</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Driving innovation in automation and e-mobility solutions
          </p>
        </motion.div>

        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "show" : "hidden"}
          className="max-w-6xl mx-auto space-y-16"
        >
          <motion.div variants={itemVariants} className="bg-white/90 backdrop-blur-sm p-10 rounded-2xl shadow-xl">
            <div className="flex items-center justify-center mb-8">
              <div className="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center">
                <CheckCircle className="w-10 h-10 text-red-600" />
              </div>
            </div>
            <ul className="grid md:grid-cols-3 gap-6">
              <li className="flex items-start space-x-3">
                <div className="flex-shrink-0 mt-1">
                  <div className="w-5 h-5 rounded-full bg-red-500 flex items-center justify-center">
                    <span className="text-white text-xs">✓</span>
                  </div>
                </div>
                <p className="text-gray-700">25+ years of experience in industrial and automotive markets</p>
              </li>
              <li className="flex items-start space-x-3">
                <div className="flex-shrink-0 mt-1">
                  <div className="w-5 h-5 rounded-full bg-red-500 flex items-center justify-center">
                    <span className="text-white text-xs">✓</span>
                  </div>
                </div>
                <p className="text-gray-700">Strong worldwide network with market leaders & standard Bodys</p>
              </li>
              <li className="flex items-start space-x-3">
                <div className="flex-shrink-0 mt-1">
                  <div className="w-5 h-5 rounded-full bg-red-500 flex items-center justify-center">
                    <span className="text-white text-xs">✓</span>
                  </div>
                </div>
                <p className="text-gray-700">Deep technical understanding of automation and e-Mobilty</p>
              </li>
            </ul>
          </motion.div>

          <motion.div variants={itemVariants}>
            <div className="flex items-center mb-6">
              <Target className="w-8 h-8 text-red-600 mr-3" />
              <h2 className="text-3xl font-bold">Vision</h2>
            </div>
            <div className="bg-gradient-to-r from-gray-900 to-red-900 text-white p-10 rounded-2xl shadow-xl">
              <ul className="space-y-4">
                <li className="flex items-start space-x-3">
                  <div className="flex-shrink-0 mt-1">
                    <div className="w-5 h-5 rounded-full bg-white flex items-center justify-center">
                      <span className="text-red-800 text-xs">✓</span>
                    </div>
                  </div>
                  <p>Drive automation and E-Mobility in growing markets (Morocco, Africa)</p>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="flex-shrink-0 mt-1">
                    <div className="w-5 h-5 rounded-full bg-white flex items-center justify-center">
                      <span className="text-red-800 text-xs">✓</span>
                    </div>
                  </div>
                  <p>Leverage the strong Eco system for a cost optimized green solutions</p>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="flex-shrink-0 mt-1">
                    <div className="w-5 h-5 rounded-full bg-white flex items-center justify-center">
                      <span className="text-red-800 text-xs">✓</span>
                    </div>
                  </div>
                  <p>Support companies / countries for better environmental sustainability</p>
                </li>
              </ul>
            </div>
          </motion.div>

          <motion.div variants={itemVariants}>
            <div className="flex items-center mb-6">
              <Award className="w-8 h-8 text-red-600 mr-3" />
              <h2 className="text-3xl font-bold">Goals</h2>
            </div>
            <div className="bg-white/90 backdrop-blur-sm p-10 rounded-2xl shadow-xl border-l-8 border-red-500">
              <ul className="space-y-4">
                <li className="flex items-start space-x-3">
                  <div className="flex-shrink-0 mt-1">
                    <div className="w-5 h-5 rounded-full bg-red-500 flex items-center justify-center">
                      <span className="text-white text-xs">✓</span>
                    </div>
                  </div>
                  <p className="text-gray-700">Support companies in digital transformation & process optimization</p>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="flex-shrink-0 mt-1">
                    <div className="w-5 h-5 rounded-full bg-red-500 flex items-center justify-center">
                      <span className="text-white text-xs">✓</span>
                    </div>
                  </div>
                  <p className="text-gray-700">
                    Achieve increased production efficiency and reduced production costs and C02 emissions through
                    modern energy and process monitoring
                  </p>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="flex-shrink-0 mt-1">
                    <div className="w-5 h-5 rounded-full bg-red-500 flex items-center justify-center">
                      <span className="text-white text-xs">✓</span>
                    </div>
                  </div>
                  <p className="text-gray-700">Enhance efficiency and competitiveness of companies</p>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="flex-shrink-0 mt-1">
                    <div className="w-5 h-5 rounded-full bg-red-500 flex items-center justify-center">
                      <span className="text-white text-xs">✓</span>
                    </div>
                  </div>
                  <p className="text-gray-700">Develop innovative solutions for intralogistics and e-mobility</p>
                </li>
              </ul>
            </div>
          </motion.div>

          <motion.div variants={itemVariants}>
            <div className="flex items-center mb-6">
              <Leaf className="w-8 h-8 text-red-600 mr-3" />
              <h2 className="text-3xl font-bold">Values</h2>
            </div>
            <div className="grid md:grid-cols-5 gap-4">
              <div className="bg-white/90 backdrop-blur-sm p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow text-center">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Leaf className="w-6 h-6 text-green-600" />
                </div>
                <h3 className="font-bold mb-2">Environmentally Conscious</h3>
                <p className="text-sm text-gray-600">Reduction of C02 emissions – Electricification</p>
              </div>
              <div className="bg-white/90 backdrop-blur-sm p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow text-center">
                <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Award className="w-6 h-6 text-yellow-600" />
                </div>
                <h3 className="font-bold mb-2">Innovation</h3>
                <p className="text-sm text-gray-600">Pushing boundaries with cutting-edge solutions</p>
              </div>
              <div className="bg-white/90 backdrop-blur-sm p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow text-center">
                <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Target className="w-6 h-6 text-yellow-600" />
                </div>
                <h3 className="font-bold mb-2">Efficiency</h3>
                <p className="text-sm text-gray-600">Optimizing processes for maximum productivity</p>
              </div>
              <div className="bg-white/90 backdrop-blur-sm p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow text-center">
                <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="w-6 h-6 text-red-600" />
                </div>
                <h3 className="font-bold mb-2">Quality</h3>
                <p className="text-sm text-gray-600">Delivering excellence in every solution</p>
              </div>
              <div className="bg-white/90 backdrop-blur-sm p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow text-center">
                <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="w-6 h-6 text-red-600" />
                </div>
                <h3 className="font-bold mb-2">Customer orientation</h3>
                <p className="text-sm text-gray-600">Putting client needs at the center of our work</p>
              </div>
            </div>
          </motion.div>

          <motion.div variants={itemVariants}>
            <div className="flex items-center mb-6">
              <Globe className="w-8 h-8 text-red-600 mr-3" />
              <h2 className="text-3xl font-bold">Target market</h2>
            </div>
            <div className="bg-gradient-to-br from-gray-50/80 to-white/80 backdrop-blur-sm p-10 rounded-2xl border border-red-100">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <ul className="space-y-4">
                    <li className="flex items-start space-x-3">
                      <div className="flex-shrink-0 mt-1">
                        <div className="w-5 h-5 rounded-full bg-red-500 flex items-center justify-center">
                          <span className="text-white text-xs">✓</span>
                        </div>
                      </div>
                      <p className="text-gray-700">Companies from Intralogistics and e-mobility industries</p>
                    </li>
                    <li className="flex items-start space-x-3">
                      <div className="flex-shrink-0 mt-1">
                        <div className="w-5 h-5 rounded-full bg-red-500 flex items-center justify-center">
                          <span className="text-white text-xs">✓</span>
                        </div>
                      </div>
                      <p className="text-gray-700">Factories and logistic centers</p>
                    </li>
                    <li className="flex items-start space-x-3">
                      <div className="flex-shrink-0 mt-1">
                        <div className="w-5 h-5 rounded-full bg-red-500 flex items-center justify-center">
                          <span className="text-white text-xs">✓</span>
                        </div>
                      </div>
                      <p className="text-gray-700">Warehouses and distribution centers</p>
                    </li>
                  </ul>
                </div>
                <div>
                  <ul className="space-y-4">
                    <li className="flex items-start space-x-3">
                      <div className="flex-shrink-0 mt-1">
                        <div className="w-5 h-5 rounded-full bg-red-500 flex items-center justify-center">
                          <span className="text-white text-xs">✓</span>
                        </div>
                      </div>
                      <p className="text-gray-700">Food and beverages – industry 4.0 in supply chain</p>
                    </li>
                    <li className="flex items-start space-x-3">
                      <div className="flex-shrink-0 mt-1">
                        <div className="w-5 h-5 rounded-full bg-red-500 flex items-center justify-center">
                          <span className="text-white text-xs">✓</span>
                        </div>
                      </div>
                      <p className="text-gray-700">Data centers</p>
                    </li>
                    <li className="flex items-start space-x-3">
                      <div className="flex-shrink-0 mt-1">
                        <div className="w-5 h-5 rounded-full bg-red-500 flex items-center justify-center">
                          <span className="text-white text-xs">✓</span>
                        </div>
                      </div>
                      <p className="text-gray-700">Companies seeking to automate and optimize their processes</p>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}

