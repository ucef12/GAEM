"use client"

import { useRef } from "react"
import { Wifi, Database } from "lucide-react"
import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Button } from "@/components/ui/button"
import Image from "next/image"

export default function IoTGateway() {
  const videoRef = useRef<HTMLIFrameElement>(null)
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const containerVariants = {
    hidden: {},
    show: {
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  }

  return (
    <section className="pt-32 pb-20 relative">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <Image
          src="https://images.unsplash.com/photo-1544197150-b99a580bb7a8?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3"
          alt="IoT Network Background"
          layout="fill"
          objectFit="cover"
          className="opacity-10"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-gray-50/80 to-white/90"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block bg-black text-white px-4 py-1 rounded-full text-sm font-medium mb-4">
            Connectivity Solution
          </span>
          <h1 className="text-4xl md:text-5xl font-bold mb-6">IoT Gateway</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Seamlessly connect your industrial devices to the cloud
          </p>
        </motion.div>

        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "show" : "hidden"}
          className="max-w-6xl mx-auto mb-16"
        >
          <div className="grid md:grid-cols-2 gap-8 my-16">
            <motion.div variants={itemVariants} className="order-1 md:order-1">
              <div className="bg-white/90 backdrop-blur-sm p-8 rounded-xl shadow-lg">
                <h2 className="text-3xl font-bold mb-6 text-gray-800 border-l-4 border-black pl-4">
                  Access to Data in Modbus PLCs from The Cloud via MQTT
                </h2>
                <div className="flex items-center mb-4">
                  <div className="flex space-x-2">
                    <span className="bg-red-100 text-red-800 px-3 py-1 rounded-full text-sm font-medium">EASY</span>
                    <span className="bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-sm font-medium">
                      SMART
                    </span>
                    <span className="bg-gray-100 text-gray-800 px-3 py-1 rounded-full text-sm font-medium">
                      CUSTOMIZABLE
                    </span>
                  </div>
                </div>
                <p className="text-gray-700 mb-6">
                  The configurable Gateway ELCO35 enables communication between Modbus-RTU/ Modbus TCP Slave devices and
                  MQTT broker/server). The communication is bidirectional, allowing for the reading of data from Modbus
                  slave devices and writing to Modbus slave devices.
                </p>
                <p className="text-gray-700">
                  The Gateway can send data read from Modbus to configurable topics on the MQTT broker (Publish) and
                  receive configurable topics (Subscribe) to write this data into Modbus.
                </p>
              </div>
            </motion.div>

            <motion.div variants={itemVariants} className="order-2 md:order-2">
              <div className="sticky top-32">
                <div className="aspect-w-16 aspect-h-9">
                  <iframe
                    className="w-full h-[300px] rounded-xl shadow-lg"
                    src="https://www.youtube-nocookie.com/embed/ZBzn62Cjd8c"
                    title="IoT Gateway"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  ></iframe>
                </div>
              </div>
            </motion.div>
          </div>

          <motion.div variants={itemVariants} className="my-16">
            <div className="bg-gradient-to-r from-gray-900 to-black text-white p-10 rounded-2xl shadow-xl">
              <div className="grid md:grid-cols-2 gap-8">
                <div>
                  <h2 className="text-3xl font-bold mb-6">Why Choose Us?</h2>
                  <h3 className="text-2xl font-bold mb-3 text-gray-300">AccessData from The Cloud</h3>
                </div>
                <div>
                  <ul className="space-y-4">
                    <li className="flex items-start space-x-3">
                      <div className="flex-shrink-0 mt-1">
                        <div className="w-5 h-5 rounded-full bg-red-500 flex items-center justify-center">
                          <span className="text-white text-xs">✓</span>
                        </div>
                      </div>
                      <p className="text-gray-300">
                        Read and write access to Modbus controllers, e.g. from Schneider Electric, Wago, Beckhoff,
                        Phoenix Contact, Sensors, Actuators, E-Meters, etc.
                      </p>
                    </li>
                    <li className="flex items-start space-x-3">
                      <div className="flex-shrink-0 mt-1">
                        <div className="w-5 h-5 rounded-full bg-yellow-500 flex items-center justify-center">
                          <span className="text-white text-xs">✓</span>
                        </div>
                      </div>
                      <p className="text-gray-300">
                        Easy local and global access to field data and routing through firewalls
                      </p>
                    </li>
                    <li className="flex items-start space-x-3">
                      <div className="flex-shrink-0 mt-1">
                        <div className="w-5 h-5 rounded-full bg-black flex items-center justify-center">
                          <span className="text-white text-xs">✓</span>
                        </div>
                      </div>
                      <p className="text-gray-300">
                        Especially dedicated to retrofit upgrades, thus protecting former investments
                      </p>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div variants={itemVariants} className="my-16">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-black/20 to-red-500/20 rounded-2xl"></div>
              <div className="relative p-8 md:p-12">
                <div className="grid md:grid-cols-2 gap-8 items-center">
                  <div>
                    <ul className="space-y-4">
                      <li className="flex items-start space-x-3">
                        <div className="flex-shrink-0 mt-1">
                          <div className="w-5 h-5 rounded-full bg-black flex items-center justify-center">
                            <span className="text-white text-xs">✓</span>
                          </div>
                        </div>
                        <p className="text-gray-700">
                          No need for software updates, operating system patches and PC updates resulting in years of
                          failure-free operation
                        </p>
                      </li>
                      <li className="flex items-start space-x-3">
                        <div className="flex-shrink-0 mt-1">
                          <div className="w-5 h-5 rounded-full bg-red-500 flex items-center justify-center">
                            <span className="text-white text-xs">✓</span>
                          </div>
                        </div>
                        <p className="text-gray-700">Minimal PLC programming for register setup required</p>
                      </li>
                      <li className="flex items-start space-x-3">
                        <div className="flex-shrink-0 mt-1">
                          <div className="w-5 h-5 rounded-full bg-yellow-500 flex items-center justify-center">
                            <span className="text-white text-xs">✓</span>
                          </div>
                        </div>
                        <p className="text-gray-700">No dedicated PC required</p>
                      </li>
                      <li className="flex items-start space-x-3">
                        <div className="flex-shrink-0 mt-1">
                          <div className="w-5 h-5 rounded-full bg-black flex items-center justify-center">
                            <span className="text-white text-xs">✓</span>
                          </div>
                        </div>
                        <p className="text-gray-700">Web-based interface for gateway configuration</p>
                      </li>
                    </ul>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-white/90 backdrop-blur-sm p-6 rounded-lg shadow-md">
                      <Wifi className="w-12 h-12 text-red-600 mb-4" />
                      <h3 className="text-xl font-bold mb-3">Seamless Connectivity</h3>
                      <p>Connect legacy industrial equipment to modern cloud platforms with minimal effort.</p>
                    </div>
                    <div className="bg-white/90 backdrop-blur-sm p-6 rounded-lg shadow-md">
                      <Database className="w-12 h-12 text-yellow-600 mb-4" />
                      <h3 className="text-xl font-bold mb-3">Data Management</h3>
                      <p>Efficient data collection and processing from multiple industrial sources.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div variants={itemVariants} className="my-16">
            <div className="bg-white/90 backdrop-blur-sm p-8 rounded-xl shadow-lg">
              <h2 className="text-2xl font-bold mb-6 text-gray-800 border-l-4 border-black pl-4">
                ELCO35 IOT Gateway Specification
              </h2>
              <div className="grid md:grid-cols-2 gap-8">
                <div>
                  <div className="overflow-x-auto">
                    <table className="min-w-full bg-white">
                      <thead>
                        <tr>
                          <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Parameter
                          </th>
                          <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Value
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td className="py-2 px-4 border-b border-gray-200">Standard</td>
                          <td className="py-2 px-4 border-b border-gray-200">Modbus / Modbus TCP / MQTT</td>
                        </tr>
                        <tr>
                          <td className="py-2 px-4 border-b border-gray-200">Dimensions (H×W×D)</td>
                          <td className="py-2 px-4 border-b border-gray-200">90mm×35mm×61mm</td>
                        </tr>
                        <tr>
                          <td className="py-2 px-4 border-b border-gray-200">Weight (depending on variant)</td>
                          <td className="py-2 px-4 border-b border-gray-200">~150g (0.33 pounds)</td>
                        </tr>
                        <tr>
                          <td className="py-2 px-4 border-b border-gray-200">Mounting</td>
                          <td className="py-2 px-4 border-b border-gray-200">DIN-Rail</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
                <div className="flex justify-center items-center">
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="text-lg font-medium mb-4 text-gray-700">DIN-Rail Sockets</h3>
                    <div className="flex justify-center">
                      <Image
                        src="/placeholder.svg?height=200&width=150"
                        alt="DIN-Rail Socket"
                        width={150}
                        height={200}
                        className="rounded-lg shadow"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div variants={itemVariants} className="text-center mt-16">
            <Button size="lg" className="bg-black hover:bg-gray-800 text-white px-8 py-6 rounded-md">
              Request Technical Specifications
            </Button>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}

