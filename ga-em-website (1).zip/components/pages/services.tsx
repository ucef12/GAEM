"use client"

import { Settings, Cloud, Truck, Battery, Zap, Shield, Users } from "lucide-react"
import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Button } from "@/components/ui/button"

export default function Services() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const containerVariants = {
    hidden: {},
    show: {
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  }

  return (
    <section className="pt-32 pb-20 relative">
      {/* Background Video */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        <video
          autoPlay
          loop
          muted
          className="w-full h-full object-cover opacity-10"
          poster="/placeholder.svg?height=1080&width=1920"
        >
          <source
            src="https://player.vimeo.com/progressive_redirect/playback/689227087/rendition/720p?loc=external&oauth2_token_id=57447761&signature=d0a4e2c2b0e2c1f0b8e5f0e0f8e3c2a6a5a6c0a6a5a6c0a6a5a6c0a6a5a6c0"
            type="video/mp4"
          />
          Your browser does not support the video tag.
        </video>
        <div className="absolute inset-0 bg-gradient-to-b from-gray-50/80 to-white/90"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block bg-orange-600 text-white px-4 py-1 rounded-full text-sm font-medium mb-4">
            What We Offer
          </span>
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Our Services</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Comprehensive solutions for automation and e-mobility needs
          </p>
        </motion.div>

        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "show" : "hidden"}
          className="max-w-6xl mx-auto"
        >
          <div className="grid md:grid-cols-2 gap-8 mb-16">
            <motion.div
              variants={itemVariants}
              whileHover={{ y: -10 }}
              className="bg-white/90 backdrop-blur-sm rounded-2xl shadow-xl overflow-hidden group"
            >
              <div className="h-3 bg-gradient-to-r from-orange-500 to-red-500"></div>
              <div className="p-8">
                <div className="w-16 h-16 bg-orange-100 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-orange-200 transition-colors">
                  <Settings className="w-8 h-8 text-orange-600" />
                </div>
                <h3 className="text-2xl font-bold mb-4">Consulting and Development</h3>
                <p className="text-gray-600 mb-6">
                  Comprehensive consulting and development of automation & e-Mobility solutions
                </p>
                <div className="flex items-center text-orange-600 font-medium">
                  <span>Learn more</span>
                  <Zap className="ml-2 w-4 h-4" />
                </div>
              </div>
            </motion.div>

            <motion.div
              variants={itemVariants}
              whileHover={{ y: -10 }}
              className="bg-white/90 backdrop-blur-sm rounded-2xl shadow-xl overflow-hidden group"
            >
              <div className="h-3 bg-gradient-to-r from-blue-500 to-indigo-500"></div>
              <div className="p-8">
                <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-blue-200 transition-colors">
                  <Cloud className="w-8 h-8 text-blue-600" />
                </div>
                <h3 className="text-2xl font-bold mb-4">End-to-End Integration</h3>
                <p className="text-gray-600 mb-6">From Concept to solution - Integration from Sensor to the cloud</p>
                <div className="flex items-center text-blue-600 font-medium">
                  <span>Learn more</span>
                  <Zap className="ml-2 w-4 h-4" />
                </div>
              </div>
            </motion.div>

            <motion.div
              variants={itemVariants}
              whileHover={{ y: -10 }}
              className="bg-white/90 backdrop-blur-sm rounded-2xl shadow-xl overflow-hidden group"
            >
              <div className="h-3 bg-gradient-to-r from-green-500 to-teal-500"></div>
              <div className="p-8">
                <div className="w-16 h-16 bg-green-100 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-green-200 transition-colors">
                  <Truck className="w-8 h-8 text-green-600" />
                </div>
                <h3 className="text-2xl font-bold mb-4">Industrial e-Mobility</h3>
                <p className="text-gray-600 mb-6">Industrial e-Mobility Trading with flexible acquisition options</p>
                <div className="flex items-center text-green-600 font-medium">
                  <span>Learn more</span>
                  <Zap className="ml-2 w-4 h-4" />
                </div>
              </div>
            </motion.div>

            <motion.div
              variants={itemVariants}
              whileHover={{ y: -10 }}
              className="bg-white/90 backdrop-blur-sm rounded-2xl shadow-xl overflow-hidden group"
            >
              <div className="h-3 bg-gradient-to-r from-purple-500 to-pink-500"></div>
              <div className="p-8">
                <div className="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-purple-200 transition-colors">
                  <Battery className="w-8 h-8 text-purple-600" />
                </div>
                <h3 className="text-2xl font-bold mb-4">Equipment Solutions</h3>
                <p className="text-gray-600 mb-6">
                  Flexible acquisition options: Purchase or lease recommended end equipment
                </p>
                <div className="flex items-center text-purple-600 font-medium">
                  <span>Learn more</span>
                  <Zap className="ml-2 w-4 h-4" />
                </div>
              </div>
            </motion.div>
          </div>

          <motion.div
            variants={itemVariants}
            className="bg-gradient-to-r from-gray-900 to-gray-800 text-white p-10 rounded-2xl shadow-xl my-16"
          >
            <h2 className="text-3xl font-bold mb-8">Additional Benefits</h2>
            <div className="grid md:grid-cols-2 gap-8">
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center">
                    <Shield className="w-6 h-6 text-orange-400" />
                  </div>
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">One Stop Shop</h3>
                  <p className="text-gray-300">Benefit from an annual subscription for products maintenance</p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center">
                    <Users className="w-6 h-6 text-blue-400" />
                  </div>
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">Expert Support</h3>
                  <p className="text-gray-300">Support from experts ensuring seamless operation</p>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div variants={itemVariants} className="text-center mt-16">
            <Button size="lg" className="bg-orange-600 hover:bg-orange-700 text-white px-8 py-6 rounded-md">
              Request Service Consultation
            </Button>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}

