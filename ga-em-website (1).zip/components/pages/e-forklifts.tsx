"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Battery, TrendingUp, Leaf, DollarSign, Volume2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import dynamic from "next/dynamic"
import Image from "next/image"

const ForkliftModel = dynamic(() => import("@/components/3d/forklift-model"), { ssr: false })

export default function EForklifts() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const containerVariants = {
    hidden: {},
    show: {
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  }

  return (
    <section className="pt-32 pb-20 relative">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <Image
          src="https://images.unsplash.com/photo-1581092918056-0c4c3acd3789?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3"
          alt="Warehouse Technology Background"
          layout="fill"
          objectFit="cover"
          className="opacity-10"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-gray-50/80 to-white/90"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block bg-yellow-600 text-white px-4 py-1 rounded-full text-sm font-medium mb-4">
            Sustainable Mobility
          </span>
          <h1 className="text-4xl md:text-5xl font-bold mb-6">e-Forklifts</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Electric forklifts for efficient and sustainable material handling
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-12 max-w-6xl mx-auto">
          <motion.div
            ref={ref}
            variants={containerVariants}
            initial="hidden"
            animate={inView ? "show" : "hidden"}
            className="flex flex-col justify-center"
          >
            <motion.div
              variants={itemVariants}
              className="bg-white/90 backdrop-blur-sm p-10 rounded-2xl shadow-xl mb-8"
            >
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center mr-4">
                  <TrendingUp className="w-6 h-6 text-yellow-600" />
                </div>
                <h2 className="text-2xl font-bold">Market for e-Forklifts</h2>
              </div>

              <p className="text-lg mb-6 text-gray-700">
                Morocco's strategic location and growing economy make it attractive market for Forklifts businesses.
                Logistics and warehousing sectors are expanding, driving demand for efficient material handling
                solutions.
              </p>

              <div className="bg-gradient-to-r from-yellow-50 to-amber-50 p-6 rounded-xl border border-yellow-100 mt-8">
                <h3 className="text-xl font-bold mb-4 text-gray-800">Market Statistics</h3>
                <div className="grid grid-cols-3 gap-4">
                  <div className="bg-white p-4 rounded-lg shadow-sm text-center">
                    <span className="block text-sm text-gray-500 mb-1">Today</span>
                    <span className="text-xl font-bold text-yellow-600">2ku/y</span>
                  </div>
                  <div className="bg-white p-4 rounded-lg shadow-sm text-center">
                    <span className="block text-sm text-gray-500 mb-1">Growth</span>
                    <span className="text-xl font-bold text-yellow-600">~25%</span>
                  </div>
                  <div className="bg-white p-4 rounded-lg shadow-sm text-center">
                    <span className="block text-sm text-gray-500 mb-1">Projection</span>
                    <span className="text-xl font-bold text-yellow-600">15Ku by 2030</span>
                  </div>
                </div>
              </div>
            </motion.div>

            <motion.div variants={itemVariants} className="bg-white/90 backdrop-blur-sm p-10 rounded-2xl shadow-xl">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mr-4">
                  <Leaf className="w-6 h-6 text-green-600" />
                </div>
                <h3 className="text-2xl font-bold">Benefits of e-Forklifts</h3>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-start space-x-3">
                  <div className="flex-shrink-0 mt-1">
                    <Leaf className="w-5 h-5 text-green-600" />
                  </div>
                  <p className="text-gray-700">Zero emissions for cleaner work environments</p>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="flex-shrink-0 mt-1">
                    <DollarSign className="w-5 h-5 text-green-600" />
                  </div>
                  <p className="text-gray-700">Lower operating costs compared to diesel forklifts</p>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="flex-shrink-0 mt-1">
                    <Volume2 className="w-5 h-5 text-green-600" />
                  </div>
                  <p className="text-gray-700">Reduced noise pollution in warehouses</p>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="flex-shrink-0 mt-1">
                    <Battery className="w-5 h-5 text-green-600" />
                  </div>
                  <p className="text-gray-700">Less maintenance requirements</p>
                </div>
              </div>
              <div className="mt-8 text-center">
                <Button className="bg-yellow-600 hover:bg-yellow-700 text-white">Request Information</Button>
              </div>
            </motion.div>
          </motion.div>

          <div className="h-[600px] bg-gradient-to-b from-gray-100 to-white rounded-2xl shadow-xl overflow-hidden">
            <div className="w-full h-full">
              <ForkliftModel />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

