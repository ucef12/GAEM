"use client"

import { useRef } from "react"
import { Factory, BarChart, Clock, Zap, LineChart } from "lucide-react"
import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Button } from "@/components/ui/button"

export default function Industry40() {
  const videoRef = useRef<HTMLIFrameElement>(null)
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const containerVariants = {
    hidden: {},
    show: {
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  }

  return (
    <section className="pt-32 pb-20 relative">
      {/* Background Video */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        <video autoPlay loop muted className="w-full h-full object-cover opacity-10">
          <source
            src="https://player.vimeo.com/progressive_redirect/playback/689226601/rendition/720p?loc=external&oauth2_token_id=57447761&signature=6e9e4e4f7f3d7f1c37d9ef0e0f8e3c2a6a5a6c0a6a5a6c0a6a5a6c0a6a5a6c0"
            type="video/mp4"
          />
          Your browser does not support the video tag.
        </video>
        <div className="absolute inset-0 bg-gradient-to-b from-gray-50/80 to-white/90"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block bg-yellow-600 text-white px-4 py-1 rounded-full text-sm font-medium mb-4">
            Smart Manufacturing
          </span>
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Industry 4.0</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            The fourth industrial revolution combining automation, data exchange, and manufacturing technologies
          </p>
        </motion.div>

        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "show" : "hidden"}
          className="max-w-6xl mx-auto mb-16"
        >
          <div className="grid md:grid-cols-3 gap-8 my-12">
            <motion.div
              variants={itemVariants}
              className="bg-white/90 backdrop-blur-sm rounded-xl shadow-lg p-8 border-t-4 border-red-500 hover:transform hover:scale-105 transition-all duration-300"
            >
              <div className="flex justify-center mb-6">
                <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center">
                  <Zap className="w-8 h-8 text-red-600" />
                </div>
              </div>
              <h3 className="text-xl font-bold mb-3 text-red-600 text-center">Enhancing Efficiency</h3>
              <p className="text-gray-600 text-center">Optimize capacity utilization and load distribution.</p>
            </motion.div>

            <motion.div
              variants={itemVariants}
              className="bg-white/90 backdrop-blur-sm rounded-xl shadow-lg p-8 border-t-4 border-yellow-500 hover:transform hover:scale-105 transition-all duration-300"
            >
              <div className="flex justify-center mb-6">
                <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center">
                  <BarChart className="w-8 h-8 text-yellow-600" />
                </div>
              </div>
              <h3 className="text-xl font-bold mb-3 text-yellow-600 text-center">Budget Reduction</h3>
              <p className="text-gray-600 text-center">Cost-efficient solution by upgrading legacy machines.</p>
            </motion.div>

            <motion.div
              variants={itemVariants}
              className="bg-white/90 backdrop-blur-sm rounded-xl shadow-lg p-8 border-t-4 border-black hover:transform hover:scale-105 transition-all duration-300"
            >
              <div className="flex justify-center mb-6">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center">
                  <Clock className="w-8 h-8 text-gray-800" />
                </div>
              </div>
              <h3 className="text-xl font-bold mb-3 text-gray-800 text-center">Real-Time Information</h3>
              <p className="text-gray-600 text-center">
                Visualization of real-time data, maintenance notifications and order progress.
              </p>
            </motion.div>
          </div>

          <div className="grid md:grid-cols-2 gap-8 my-16">
            <motion.div variants={itemVariants} className="order-1 md:order-1">
              <div className="bg-white/90 backdrop-blur-sm p-8 rounded-xl shadow-lg">
                <h2 className="text-3xl font-bold mb-6 text-gray-800 border-l-4 border-yellow-500 pl-4">
                  Digital Factory Transformation
                </h2>
                <div className="flex items-center mb-4">
                  <div className="flex space-x-2">
                    <span className="bg-red-100 text-red-800 px-3 py-1 rounded-full text-sm font-medium">EASY</span>
                    <span className="bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-sm font-medium">
                      SMART
                    </span>
                    <span className="bg-gray-100 text-gray-800 px-3 py-1 rounded-full text-sm font-medium">
                      CUSTOMIZABLE
                    </span>
                  </div>
                </div>
                <p className="text-gray-700 mb-6">
                  Industry 4.0 and industrial internet of things (IIoT) are reshaping manufacturing processes and
                  products by leveraging sensor data, machine-to-machine communication (m2m) and automation
                  technologies.
                </p>
                <p className="text-gray-700">
                  Elco Solutions provides production intelligence consultancy supporting manufacturing organizations in
                  improving productivity and reducing production time and costs. Our real-time factory floor monitoring
                  and supervision tool features capability to measure key performance indicators, enabling data-driven
                  decisions and statistical process control.
                </p>
                <p className="text-gray-700 mt-4">
                  The entire production process from raw-material consumption up to order progress can be monitored
                  providing a detailed real-time data source for management and planning.
                </p>
              </div>
            </motion.div>

            <motion.div variants={itemVariants} className="order-2 md:order-2">
              <div className="sticky top-32">
                <div className="aspect-w-16 aspect-h-9">
                  <iframe
                    className="w-full h-[300px] rounded-xl shadow-lg"
                    src="https://www.youtube-nocookie.com/embed/Ie7JXTNPsOc"
                    title="Industry 4.0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  ></iframe>
                </div>
              </div>
            </motion.div>
          </div>

          <motion.div variants={itemVariants} className="my-16">
            <div className="bg-gradient-to-r from-gray-900 to-yellow-900 text-white p-10 rounded-2xl shadow-xl">
              <div className="grid md:grid-cols-2 gap-8">
                <div>
                  <h2 className="text-3xl font-bold mb-6">Why Choose Us?</h2>
                  <h3 className="text-2xl font-bold mb-3 text-yellow-400">Gain real-time Insights</h3>
                  <p className="text-lg mb-6 text-gray-300">About your Production Area</p>
                </div>
                <div>
                  <p className="text-gray-300">
                    Software is key for companies to surf the digital wave. This is important as digital is the new
                    normal. Adapt or be disrupted! Companies are either born digital or they are in the midst of a rapid
                    digital transformation. Elco Solutions is helping organizations accelerate time-to-market, creating
                    new products/services, driving operational efficiencies, and delivering new client experiences.
                  </p>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div variants={itemVariants} className="my-16">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-yellow-500/20 to-red-500/20 rounded-2xl"></div>
              <div className="relative p-8 md:p-12">
                <div className="grid md:grid-cols-2 gap-8 items-center">
                  <div>
                    <div className="grid md:grid-cols-2 gap-6">
                      <div className="bg-white/90 backdrop-blur-sm p-6 rounded-lg shadow-md">
                        <LineChart className="w-12 h-12 text-yellow-600 mb-4" />
                        <h3 className="text-xl font-bold mb-3">Data-Driven Manufacturing</h3>
                        <p>
                          Make informed decisions based on real-time data from your production floor, improving quality
                          and reducing waste.
                        </p>
                      </div>
                      <div className="bg-white/90 backdrop-blur-sm p-6 rounded-lg shadow-md">
                        <Factory className="w-12 h-12 text-red-600 mb-4" />
                        <h3 className="text-xl font-bold mb-3">Smart Factory Solutions</h3>
                        <p>
                          Transform your traditional factory into a smart, connected facility with our end-to-end
                          Industry 4.0 solutions.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div variants={itemVariants} className="text-center mt-16">
            <Button size="lg" className="bg-yellow-600 hover:bg-yellow-700 text-white px-8 py-6 rounded-md">
              Request a Demo
            </Button>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}

