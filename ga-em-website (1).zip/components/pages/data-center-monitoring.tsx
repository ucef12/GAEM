"use client"

import { useRef } from "react"
import { Server, BarChart3, Thermometer, Activity, Shield } from "lucide-react"
import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Button } from "@/components/ui/button"
import Image from "next/image"

export default function DataCenterMonitoring() {
  const videoRef = useRef<HTMLIFrameElement>(null)
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const containerVariants = {
    hidden: {},
    show: {
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  }

  return (
    <section className="pt-32 pb-20 relative">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <Image
          src="https://images.unsplash.com/photo-1558494949-ef010cbdcc31?q=80&w=2034&auto=format&fit=crop&ixlib=rb-4.0.3"
          alt="Data Center Background"
          layout="fill"
          objectFit="cover"
          className="opacity-10"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-gray-50/80 to-white/90"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block bg-red-600 text-white px-4 py-1 rounded-full text-sm font-medium mb-4">
            Monitoring Solution
          </span>
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Data Center Monitoring</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Comprehensive monitoring solutions for modern data centers
          </p>
        </motion.div>

        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "show" : "hidden"}
          className="max-w-6xl mx-auto mb-16"
        >
          <div className="grid md:grid-cols-3 gap-8 my-12">
            <motion.div
              variants={itemVariants}
              className="bg-white/90 backdrop-blur-sm rounded-xl shadow-lg p-8 border-t-4 border-red-500 hover:transform hover:scale-105 transition-all duration-300"
            >
              <div className="flex justify-center mb-6">
                <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center">
                  <Thermometer className="w-8 h-8 text-red-600" />
                </div>
              </div>
              <h3 className="text-xl font-bold mb-3 text-red-600 text-center">Enhancing Efficiency</h3>
              <p className="text-gray-600 text-center">Ensure uptime by monitoring racks for potential hotspots.</p>
            </motion.div>

            <motion.div
              variants={itemVariants}
              className="bg-white/90 backdrop-blur-sm rounded-xl shadow-lg p-8 border-t-4 border-yellow-500 hover:transform hover:scale-105 transition-all duration-300"
            >
              <div className="flex justify-center mb-6">
                <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center">
                  <BarChart3 className="w-8 h-8 text-yellow-600" />
                </div>
              </div>
              <h3 className="text-xl font-bold mb-3 text-yellow-600 text-center">Budget Reduction</h3>
              <p className="text-gray-600 text-center">Efficient energy management and cost reduction.</p>
            </motion.div>

            <motion.div
              variants={itemVariants}
              className="bg-white/90 backdrop-blur-sm rounded-xl shadow-lg p-8 border-t-4 border-black hover:transform hover:scale-105 transition-all duration-300"
            >
              <div className="flex justify-center mb-6">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center">
                  <Activity className="w-8 h-8 text-gray-800" />
                </div>
              </div>
              <h3 className="text-xl font-bold mb-3 text-gray-800 text-center">Asset Management</h3>
              <p className="text-gray-600 text-center">
                Ensure high quality and provide customer specific reports of environmental conditions.
              </p>
            </motion.div>
          </div>

          <div className="grid md:grid-cols-2 gap-8 my-16">
            <motion.div variants={itemVariants} className="order-1 md:order-1">
              <div className="bg-white/90 backdrop-blur-sm p-8 rounded-xl shadow-lg">
                <h2 className="text-3xl font-bold mb-6 text-gray-800 border-l-4 border-red-500 pl-4">
                  DCIM Environmental Conditions Monitoring
                </h2>
                <div className="flex items-center mb-4">
                  <div className="flex space-x-2">
                    <span className="bg-red-100 text-red-800 px-3 py-1 rounded-full text-sm font-medium">EASY</span>
                    <span className="bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-sm font-medium">
                      SMART
                    </span>
                    <span className="bg-gray-100 text-gray-800 px-3 py-1 rounded-full text-sm font-medium">
                      CUSTOMIZABLE
                    </span>
                  </div>
                </div>
                <p className="text-gray-700 mb-6">
                  As data center and facility managers continuously strive to improve energy efficiency, environmental
                  monitoring is becoming crucial. Only on the basis of parameters can an objective conclusion be made
                  about the power usage effectiveness. Data based optimization of cooling load and power management at
                  PDUs, Racks, Cabinet rows, rooms etc.
                </p>
              </div>
            </motion.div>

            <motion.div variants={itemVariants} className="order-2 md:order-2">
              <div className="sticky top-32">
                <div className="aspect-w-16 aspect-h-9">
                  <iframe
                    className="w-full h-[300px] rounded-xl shadow-lg"
                    src="https://www.youtube-nocookie.com/embed/zVsMQMkl-8U"
                    title="Data Center Monitoring"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  ></iframe>
                </div>
              </div>
            </motion.div>
          </div>

          <motion.div variants={itemVariants} className="my-16">
            <div className="bg-gradient-to-r from-gray-900 to-red-900 text-white p-10 rounded-2xl shadow-xl">
              <div className="grid md:grid-cols-2 gap-8">
                <div>
                  <h2 className="text-3xl font-bold mb-6">Why Choose Us?</h2>
                  <h3 className="text-2xl font-bold mb-3 text-red-400">Gain real-time Insights</h3>
                  <p className="text-lg mb-6 text-gray-300">About your Data Center Environment</p>
                </div>
                <div>
                  <p className="text-gray-300">
                    ElcoEMS is a cutting-edge tool designed to provide real-time insights into your data center
                    environment. It monitors key parameters such as temperature, humidity, and power usage, ensuring
                    optimal performance and safety. With ElcoEMS, you can proactively manage your data center's
                    environmental conditions, reduce energy consumption, and prevent costly downtime, all while ensuring
                    compliance with industry standards.
                  </p>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div variants={itemVariants} className="my-16">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-red-500/20 to-yellow-500/20 rounded-2xl"></div>
              <div className="relative p-8 md:p-12">
                <div className="grid md:grid-cols-2 gap-8 items-center">
                  <div>
                    <div className="grid md:grid-cols-2 gap-6">
                      <div className="bg-white/90 backdrop-blur-sm p-6 rounded-lg shadow-md">
                        <Server className="w-12 h-12 text-red-600 mb-4" />
                        <h3 className="text-xl font-bold mb-3">Infrastructure Monitoring</h3>
                        <p>
                          Complete monitoring of your data center infrastructure including power, cooling, and security
                          systems.
                        </p>
                      </div>
                      <div className="bg-white/90 backdrop-blur-sm p-6 rounded-lg shadow-md">
                        <Shield className="w-12 h-12 text-yellow-600 mb-4" />
                        <h3 className="text-xl font-bold mb-3">Predictive Maintenance</h3>
                        <p>
                          Early detection of potential issues through advanced analytics and predictive maintenance
                          capabilities.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div variants={itemVariants} className="text-center mt-16">
            <Button size="lg" className="bg-red-600 hover:bg-red-700 text-white px-8 py-6 rounded-md">
              Schedule a Consultation
            </Button>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}

