"use client"

import { motion } from "framer-motion"

interface LogoProps {
  variant?: "light" | "dark"
  size?: "sm" | "md" | "lg"
}

export default function Logo({ variant = "dark", size = "md" }: LogoProps) {
  const textColor = variant === "light" ? "text-white" : "text-black"
  const sizeClasses = {
    sm: "text-xl",
    md: "text-2xl",
    lg: "text-4xl",
  }

  return (
    <motion.div
      className={`font-bold ${sizeClasses[size]} flex items-center`}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="relative">
        <span className="text-red-600 font-extrabold">G</span>
        <span className={`${textColor} font-extrabold`}>A</span>
        <span className="text-yellow-500 font-extrabold">-</span>
        <div className="absolute -top-1 -right-1 w-2 h-2 bg-red-600 rounded-full" />
      </div>
      <div className="relative ml-0.5">
        <span className="text-black font-extrabold">e</span>
        <span className="text-yellow-500 font-extrabold">M</span>
        <motion.div
          className="absolute -bottom-1 left-0 h-0.5 bg-gradient-to-r from-red-600 via-yellow-500 to-black"
          initial={{ width: 0 }}
          animate={{ width: "100%" }}
          transition={{ delay: 0.3, duration: 0.5 }}
        />
      </div>
    </motion.div>
  )
}

