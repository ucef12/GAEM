"use client"

import { Phone, Mail, MapPin, ArrowRight, Facebook, Twitter, Linkedin, Instagram } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Logo from "./logo"

export default function Footer() {
  return (
    <footer className="bg-black text-white">
      {/* Newsletter Section */}
      <div className="container mx-auto px-4 py-12">
        <div className="bg-gradient-to-r from-gray-900 to-gray-800 rounded-2xl p-8 md:p-12 mb-12">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl md:text-3xl font-bold mb-4">Stay Updated</h3>
              <p className="text-gray-300 mb-4">
                Subscribe to our newsletter for the latest updates on automation and e-mobility solutions.
              </p>
            </div>
            <div>
              <div className="flex space-x-2">
                <Input
                  type="email"
                  placeholder="Enter your email"
                  className="bg-gray-800 border-gray-700 text-white placeholder:text-gray-400 focus:border-red-500"
                />
                <Button className="bg-red-600 hover:bg-red-700 text-white">
                  <ArrowRight className="h-5 w-5" />
                </Button>
              </div>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-4 gap-12">
          <div>
            <div className="mb-6">
              <Logo variant="light" size="md" />
            </div>
            <p className="text-gray-400 mb-6">
              Leading provider of automation and e-mobility solutions for a sustainable future.
            </p>
            <div className="flex space-x-4">
              <a
                href="#"
                className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-red-600 transition-colors"
              >
                <Facebook className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-yellow-600 transition-colors"
              >
                <Twitter className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-red-600 transition-colors"
              >
                <Linkedin className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-yellow-600 transition-colors"
              >
                <Instagram className="w-5 h-5" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-xl font-bold mb-6 border-b border-gray-800 pb-2">Quick Links</h4>
            <ul className="space-y-3 text-gray-400">
              <li>
                <a href="#" className="hover:text-red-500 transition-colors flex items-center">
                  <ArrowRight className="w-4 h-4 mr-2" />
                  <span>About Us</span>
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-red-500 transition-colors flex items-center">
                  <ArrowRight className="w-4 h-4 mr-2" />
                  <span>Services</span>
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-red-500 transition-colors flex items-center">
                  <ArrowRight className="w-4 h-4 mr-2" />
                  <span>Contact</span>
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-xl font-bold mb-6 border-b border-gray-800 pb-2">Solutions</h4>
            <ul className="space-y-3 text-gray-400">
              <li>
                <a href="#" className="hover:text-yellow-500 transition-colors flex items-center">
                  <ArrowRight className="w-4 h-4 mr-2" />
                  <span>e-Mobility</span>
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-yellow-500 transition-colors flex items-center">
                  <ArrowRight className="w-4 h-4 mr-2" />
                  <span>Automation</span>
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-yellow-500 transition-colors flex items-center">
                  <ArrowRight className="w-4 h-4 mr-2" />
                  <span>Data Center</span>
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-xl font-bold mb-6 border-b border-gray-800 pb-2">Contact</h4>
            <ul className="space-y-4 text-gray-400">
              <li className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-gray-800 rounded-full flex items-center justify-center">
                  <Phone className="w-4 h-4 text-red-500" />
                </div>
                <span>+1 234 567 890</span>
              </li>
              <li className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-gray-800 rounded-full flex items-center justify-center">
                  <Mail className="w-4 h-4 text-yellow-500" />
                </div>
                <span>info@ga-em.com</span>
              </li>
              <li className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-gray-800 rounded-full flex items-center justify-center">
                  <MapPin className="w-4 h-4 text-red-500" />
                </div>
                <span>123 Business Street</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Copyright Section */}
      <div className="border-t border-gray-800">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-500 text-sm">© {new Date().getFullYear()} GA-eM. All rights reserved.</p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="text-gray-500 hover:text-white text-sm">
                Privacy Policy
              </a>
              <a href="#" className="text-gray-500 hover:text-white text-sm">
                Terms of Service
              </a>
              <a href="#" className="text-gray-500 hover:text-white text-sm">
                Sitemap
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}

