"use client"

import { useState } from "react"
import dynamic from "next/dynamic"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import HeroSection from "@/components/hero-section"
import FeaturesSection from "@/components/features-section"
import PartnersSection from "@/components/partners-section"

// Dynamically import 3D components to avoid SSR issues
const Scene3D = dynamic(() => import("@/components/scene-3d"), { ssr: false })

// Page components
const AboutUs = dynamic(() => import("@/components/pages/about-us"), { ssr: false })
const DataCenterMonitoring = dynamic(() => import("@/components/pages/data-center-monitoring"), { ssr: false })
const Industry40 = dynamic(() => import("@/components/pages/industry-40"), { ssr: false })
const IoTGateway = dynamic(() => import("@/components/pages/iot-gateway"), { ssr: false })
const EForklifts = dynamic(() => import("@/components/pages/e-forklifts"), { ssr: false })
const Services = dynamic(() => import("@/components/pages/services"), { ssr: false })
const ContactUs = dynamic(() => import("@/components/pages/contact-us"), { ssr: false })

export default function Home() {
  const [currentPage, setCurrentPage] = useState("home")
  const [currentSubPage, setCurrentSubPage] = useState<string | null>(null)

  const renderPage = () => {
    switch (currentPage) {
      case "about":
        return <AboutUs />
      case "automation":
        switch (currentSubPage) {
          case "Data Center Monitoring":
            return <DataCenterMonitoring />
          case "Industry 4.0":
            return <Industry40 />
          case "IoT Gateway":
            return <IoTGateway />
          default:
            return <DataCenterMonitoring />
        }
      case "e-mobility":
        switch (currentSubPage) {
          case "e-Forklifts":
            return <EForklifts />
          default:
            return <EForklifts />
        }
      case "services":
        return <Services />
      case "contact":
        return <ContactUs />
      default:
        return (
          <>
            <HeroSection />
            <div className="relative z-10 bg-white">
              <FeaturesSection />
              <PartnersSection />
            </div>
          </>
        )
    }
  }

  return (
    <div className="min-h-screen bg-white">
      <Navbar setCurrentPage={setCurrentPage} setCurrentSubPage={setCurrentSubPage} currentPage={currentPage} />

      {/* Main Content */}
      <main>{renderPage()}</main>

      <Footer />
    </div>
  )
}

